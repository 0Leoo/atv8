var num ;
var quan;

num = prompt('Digite algum número');
quan = prompt('Digite a quatidade de vezes que  você quer somar esse número');

while (num <= quan)
 {
    alert(`A soma é = ${num++} e a média é = ${num / quan}`);
}


