var num1 
var num2;


num1 = prompt('Digite um número inteiro');
num2 = prompt('Digite um número inteiro que sejá maior que o anterior');


for (let i = num1; i <= num2; i++)
    {
    if (i / 2 === 1){
        soma += i;
    }

    }

    
