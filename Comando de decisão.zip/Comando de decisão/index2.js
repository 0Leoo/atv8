var numero1 = Number ;
var numero2 = Number ;
var caractere ;

alert("Olá novamente, esta é a cauculadora :)");
numero1 = prompt("Digite um número inteiro")
numero2 = prompt("Digite outro número inteiro")
caractere = prompt("Agora digite um caractere (+,-,* ou /)")

if (caractere == "+")
{
    alert(`O resultado é ${numero1 + numero2}`);

}
else if (caractere == "-")
{
    alert(`O resultado é ${numero1 - numero2}`);
}
else if (caractere == "*")
{
    alert(`O resultado é ${numero1 * numero2}`);
}
else if (caractere == "/")
{
    alert(`O resultado é ${numero1 / numero2}`);
}
else 
{
    alert(`O cauculo e Inválido`);
}