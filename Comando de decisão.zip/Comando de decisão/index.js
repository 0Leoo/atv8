let saldo_inicial
let preço_compra

alert ('Olá, bem vindo(a) ou Sistema Bacário :)');
saldo_inicial = prompt('Por favor digite o seu saldo:');
preço_compra = prompt('Agora o preço da compra que deseja realizar:');
 

if (saldo_inicial < preço_compra)
 {
    alert (`Saldo insificiente. Seu saldo atual é de R$${saldo_inicial}`);

}else if (saldo_inicial >= preço_compra) 
 {
alert(`Compra realizada corretamente. Seu saldo atual é de R$${saldo_inicial - preço_compra}`);

}
